#include <iostream>
#include<vector>
#include "metrics.h"
#include <algorithm>
#include <stdio.h>
#include <string.h>


using namespace std;

const vector<std::string> classes={"center","left","right"};
const vector<string> initial={"C","L","R"};
float accuracy=0;
int matrix[3][3];

void ms::ConfusionMatrix(vector<std::string> center, vector<std::string> left, vector<std::string> right)
{
    for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
            matrix[i][j]=0;
            
    //calculate first column, aka the center column
    for(std::string x : center)
    {
        for(int j=0;j<classes.size();j++)
        {
            string a=x;
            if(classes[j].compare(x)==0)
            {
                matrix[0][j]++;
            }
        }
    }
    
    //calculate second column, aka the left column
    for(std::string x : left)
    {
        for(int j=0;j<classes.size();j++)
        {
            string a=x;
            if(classes[j].compare(x)==0)
            {
                matrix[1][j]++;
            }
        }
    }
    
    //calculate third column, aka the right column
    for(std::string x : right)
    {
        for(int j=0;j<classes.size();j++)
        {
            if(classes[j].compare(x)==0)
            {
                matrix[2][j]++;
            }
        }
    }
    

}


//function to print
void ms::printConfusionMatrix(std::vector<std::string> center, std::vector<std::string> left, std::vector<std::string> right)
{
    if(!matrix)
            ms::ConfusionMatrix(center, left, right);
    //Printing confusion matrix--
    cout<<endl;
    //print the name of the columns
    cout<<"        PREDICTED"<<endl<<"        \\ ";
    for(int i=0;i<3;i++) cout<<initial[i]<<" ";
    cout<<endl;
    //print the name of the rows
    for(int i=0;i<3;i++)
    {
        if(i==1)
            cout<<"ACTUAL  ";
        else
            cout<<"        ";
        cout<<initial[i]<<" ";
        
        //print the values
        for(int j=0;j<3;j++)
            cout<<matrix[i][j]<<" ";
        cout<<endl;
    }
        
}

float ms::CalAccuracy(std::vector<std::string> center, std::vector<std::string> left, std::vector<std::string> right)
{
    if(accuracy==0)
    {
        if(!matrix)
            ms::ConfusionMatrix(center, left, right);
        int total=center.size()+left.size()+right.size();
        //calculate accuracy as sum of TP divided by the total 
        for(int i=0;i<3;i++)
            accuracy+=matrix[i][i];
        accuracy=accuracy/total;
    }
    return accuracy;
}



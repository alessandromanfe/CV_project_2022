
#include "opencv2/objdetect.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include <iostream>
#include "daugman.h"

using namespace std;
using namespace cv;

CascadeClassifier face_cascade;
CascadeClassifier eye_cascade;


bool compareByArea(Rect &a, Rect  &b)
{
    return a.area() > b.area();
}


void faceDetection(Mat frame)
{
    Mat frame_gray;
    Mat h_frame = frame.clone();

    cvtColor(frame, frame_gray, COLOR_BGR2GRAY);

    // Detect faces 
    vector<Rect> eyes;
    vector<Rect> faces;
    face_cascade.detectMultiScale(frame_gray, faces,1.1,7,0,Size(100,100));

    int face=-1, face_area=0;
    for (int val = 0; val < faces.size(); val++)
    {
        if(faces[val].area()>face_area)
        {
            face=val;
            face_area=faces[val].area();
        }
    }
    
    //if we do not find a face we try to use the equalized image
    
    if(faces.size()<1)
    {
        //clearing old 
        faces.clear();
        eyes.clear();
        
        //equalize image
        Mat equal_img;
        equalizeHist(frame_gray, equal_img);
        //detect
        face_cascade.detectMultiScale(equal_img, faces,1.0021,8,0,Size(100,100));

        //search best face aka the face
        for (int val = 0; val < faces.size(); val++)
        {
            if(faces[val].area()>face_area)
            {
                face=val;
                face_area=faces[val].area();
            }
        }
    }
    
    if(faces.size()>=1)
    {
        //variable for eyes
        int first=-1,second=-1;
        int biggest=0;
        //print face
        //Point center(faces[face].x+ faces[face].width / 2,faces[face].y+ faces[face].height / 2);
        //ellipse(frame, center, Size(faces[face].width / 2, faces[face].height / 2), 0, 0, 360, Scalar(0, 0, 255), 6);
        //select face part
        Mat faceROI = frame_gray(faces[face]);
        
        //detect eye with different params    1.06,7
        eye_cascade.detectMultiScale(faceROI, eyes,1.06,7);
        if(eyes.size()<2)
        {
            eye_cascade.detectMultiScale(faceROI, eyes,1.03,6);
            if(eyes.size()<2)
            {
                Mat faceROI_eq;
                equalizeHist(faceROI, faceROI_eq);
                eye_cascade.detectMultiScale(faceROI_eq , eyes,1.1,5);
                if(eyes.size()<2)
                {
                     Mat faceROI_cont;
                     faceROI.convertTo(faceROI_cont, -1, 1.3, 100);
                     //imshow("Live Face Detection", faceROI_cont);
                     eye_cascade.detectMultiScale(faceROI_cont, eyes,1.025,2);
                     if(eyes.size()<2)
                     {
                         eye_cascade.detectMultiScale(faceROI, eyes,1.1,4);
                     }
                 
                }
            }
        }
        sort(eyes.begin(), eyes.end(), compareByArea);
        vector<Rect> reyes;
        if(eyes.size()>0)
        {
            //Point centereye(faces[face].x+eyes[0].x + eyes[0].width / 2,faces[face].y+ eyes[0].y + eyes[0].height / 2);
            //ellipse(frame, centereye, Size(eyes[0].width / 2, eyes[0].height / 2), 0, 0, 360, Scalar(0, 255, 0), 6);
            Rect r1 = Rect(faces[face].x + eyes[0].x, faces[face].y + eyes[0].y, eyes[0].width, eyes[0].height);
            reyes.push_back(r1);
        }
        if(eyes.size()>1)
        {
            //Point centereye(faces[face].x+eyes[1].x + eyes[1].width / 2,faces[face].y+ eyes[1].y + eyes[1].height / 2);
            //ellipse(frame, centereye, Size(eyes[1].width / 2, eyes[1].height / 2), 0, 0, 360, Scalar(0, 255, 0), 6);
            Rect r1 = Rect(faces[face].x + eyes[1].x, faces[face].y + eyes[1].y, eyes[1].width, eyes[1].height);
            reyes.push_back(r1);
        }
        /*
        float dist1=0,dist2=0,dist;
        Mat upscale;
        for (Rect r : reyes) {
            vector<int> coordVal = dm::printIris(h_frame, &h_frame, r, &upscale);
            int x=coordVal[0];
            int y=coordVal[1];
            int radius=coordVal[2];
            dist1+= x-radius;
            dist2+= upscale.cols-(x+radius);
            
        }
        */
        
        
        //Printing eyes
        if(eyes.size()>0)
        {
            Point centereye(faces[face].x+eyes[0].x + eyes[0].width / 2,faces[face].y+ eyes[0].y + eyes[0].height / 2);
            ellipse(h_frame, centereye, Size(eyes[0].width / 2, eyes[0].height / 2), 0, 0, 360, Scalar(0, 255, 0), 1);
        }
        if(eyes.size()>1)
        {
            Point centereye(faces[face].x+eyes[1].x + eyes[1].width / 2,faces[face].y+ eyes[1].y + eyes[1].height / 2);
            ellipse(h_frame, centereye, Size(eyes[1].width / 2, eyes[1].height / 2), 0, 0, 360, Scalar(0, 255, 0), 1);
        }
        /*
        int threshold=9;
        if(reyes.size()>1)
        {
            threshold=threshold*2;
            dist1=dist1/2.0;
            dist2=dist2/2.0;
        }
        if(dist1>dist2+threshold) putText(h_frame, "Left", Point(5, 20), HersheyFonts::FONT_HERSHEY_PLAIN, 1, 255, 1);
        else{
        if(dist1<dist2-threshold) putText(h_frame, "Right", Point(5, 20), HersheyFonts::FONT_HERSHEY_PLAIN, 1, 255, 1);
        else
            putText(h_frame, "Center", Point(5, 20), HersheyFonts::FONT_HERSHEY_PLAIN, 1, 255, 1);
        }
        */
    }
    
    
    //show img        
    imshow("Live Face Detection", h_frame);
}



int main(int argc, const char** argv)
{

    // Load the pre trained haar cascade classifier

    string faceClassifier = "haarcascade_frontalface_default.xml";
    string eyeClassifier = "haarcascade_eye_tree_eyeglasses.xml";
    //string faceClassifier = "haarcascade_frontalface_alt2.xml";

    if (!face_cascade.load(faceClassifier))
    {
        cout << "Could not load the classifier";
        return -1;
    };
    if (!eye_cascade.load(eyeClassifier))
    {
        cout << "Could not load the classifier";
        return -1;
    };


    vector<cv::String> fn;
    //fn.push_back("imgs/right0.jpg");
    
    //adding all images to test
    glob("imgs/*.jpg", fn, false);
    vector<String> fn1;
    glob("imgs/*.jpeg", fn1, false);
    vector<String> fn2;
    glob("imgs/*.png", fn2, false);
    fn.insert( fn.end(), fn1.begin(), fn1.end() );
    fn.insert( fn.end(), fn2.begin(), fn2.end() );
    
    Mat frame;
    
    vector<Mat> input;
    for(int j=0;j<fn.size();j++)
        input.push_back(cv::imread(fn[j]));
        
    
    for(int i=0;i<input.size();i++)
    {
        frame=input[i];
        // Apply the face detection with the haar cascade classifier
        faceDetection(frame);

        if (waitKey(100000000) == 'q')
        {
            cout<<"";// Terminate program if q pressed
        }
   }

    return 0;
}

